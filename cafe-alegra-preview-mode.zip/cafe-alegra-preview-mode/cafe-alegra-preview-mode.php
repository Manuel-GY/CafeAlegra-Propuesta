﻿<?php
/**
 * Plugin Name: Café Alegra · Previsualización Tema Hijo (Propuesta)
 * Description: Permite navegar el tema hijo cafe-alegra-child en /propuesta/ o con ?propuesta=1 sin alterar el tema GeneratePress activo en producción.
 * Version: 1.0.0
 * Author: Manuel · Café Alegra
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ca_propuesta_is_preview_request() {
	if ( is_admin() ) {
		return false;
	}
	$req_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	if ( false !== strpos( $req_uri, '/wp-admin' ) || false !== strpos( $req_uri, 'wp-login.php' ) || false !== strpos( $req_uri, '/wp-json/' ) ) {
		return false;
	}

	// Salir del modo propuesta con ?propuesta=0
	if ( isset( $_GET['propuesta'] ) && '0' === $_GET['propuesta'] ) {
		return false;
	}

	// Entrar por ?propuesta=1
	if ( isset( $_GET['propuesta'] ) && '1' === $_GET['propuesta'] ) {
		return true;
	}

	// Entrar por ruta /propuesta o /propuesta/...
	$path = trim( (string) wp_parse_url( $req_uri, PHP_URL_PATH ), '/' );
	if ( 'propuesta' === $path || 0 === strpos( $path, 'propuesta/' ) ) {
		return true;
	}

	// Cookie activa de sesión de revisión
	if ( ! empty( $_COOKIE['ca_propuesta_preview'] ) && '1' === $_COOKIE['ca_propuesta_preview'] ) {
		return true;
	}

	return false;
}

add_action( 'plugins_loaded', function() {
	if ( isset( $_GET['propuesta'] ) ) {
		if ( '0' === $_GET['propuesta'] ) {
			setcookie( 'ca_propuesta_preview', '', time() - 3600, '/' );
			unset( $_COOKIE['ca_propuesta_preview'] );
			wp_safe_redirect( remove_query_arg( 'propuesta' ) );
			exit;
		} elseif ( '1' === $_GET['propuesta'] ) {
			setcookie( 'ca_propuesta_preview', '1', time() + 7 * DAY_IN_SECONDS, '/' );
			$_COOKIE['ca_propuesta_preview'] = '1';
		}
	}
}, 1 );

add_filter( 'template', function( $template ) {
	if ( ca_propuesta_is_preview_request() && wp_get_theme( 'cafe-alegra-child' )->exists() ) {
		return 'generatepress';
	}
	return $template;
}, 99 );

add_filter( 'stylesheet', function( $stylesheet ) {
	if ( ca_propuesta_is_preview_request() && wp_get_theme( 'cafe-alegra-child' )->exists() ) {
		return 'cafe-alegra-child';
	}
	return $stylesheet;
}, 99 );

add_action( 'admin_bar_menu', function( $wp_admin_bar ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$wp_admin_bar->add_node( array(
		'id'    => 'ca-ver-propuesta',
		'title' => '☕ Ver Propuesta (Tema Hijo)',
		'href'  => home_url( '/propuesta/' ),
		'meta'  => array(
			'target' => '_blank',
			'title'  => 'Abrir la maqueta Café Alegra en el tema hijo sin afectar producción',
		),
	) );
}, 100 );